<?php 
	class FornecedoresRepo extends Repository
	{
		public function __construct($nome) 
		{
			parent::__construct($nome);
		}
	}
?>